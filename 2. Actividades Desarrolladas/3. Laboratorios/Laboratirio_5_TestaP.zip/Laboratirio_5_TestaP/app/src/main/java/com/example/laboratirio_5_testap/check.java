package com.example.laboratirio_5_testap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class check extends AppCompatActivity {
    private TextView date, time, resultado;
    private Calendar calendar;
    private EditText number1, number2;
    private CheckBox cbc1, cbc2;
    private String currentDate, currentTime, valor1, valor2, result;
    private Integer num1, num2, suma, resta;
    private Button b1, b2, b3, b4, b5, b6;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch s1;
    boolean isAllFieldsChecked = false;

    @SuppressLint("MissingInflatedId")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        cbc1 = findViewById(R.id.cbc1);
        cbc2 = findViewById(R.id.cbc2);
        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        resultado = findViewById(R.id.resultado);
        s1 = findViewById(R.id.s1);
        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dark();
            }
        });
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        b3 = findViewById(R.id.b3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                isAllFieldsChecked = validacion();
                closeKeyboard();
                reset2();
            }
        });
        b4 = findViewById(R.id.b4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                cerrar();
            }
        });
    }
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "Iniciando", Toast.LENGTH_SHORT).show(); // La actividad está a punto de hacerse visible.
        Log.d("Date and Time", "La fecha y hora actual es: " + currentDate + " " + currentTime);
        Log.d("Start", "Iniciando // La actividad está a punto de hacerse visible");
        Log.d("Materia", "Materia: Programacion VI - Asignacion N2");
        Log.d("Nombre", "Estudiante: Pablo Testa");
        Log.d("Cedula", "Cedula: 8-843-1065");
        b2 = findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                reset();
            }
        });
    }
    private void dark() {
        if (s1.isChecked()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(this, "Dark Mode Activado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "ON // El tema dark ha sido activado");
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Dark Mode Desactivado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "OFF // El tema dark ha sido desactivado");
        }
    }
    private void back() {
        Intent back = new Intent(this,Menu.class);
        startActivity(back);
    }
    private void cerrar() {
        Toast.makeText(this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        this.finish();
        System.exit(0);
    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void operacion() {
        valor1 = number1.getText().toString();
        valor2 = number2.getText().toString();
        num1 = Integer.parseInt(valor1);
        num2 = Integer.parseInt(valor2);
        result = "";
        if (cbc1.isChecked()) {
            suma = num1 + num2;
            result = "La suma es: " + suma;
        }
        if (cbc2.isChecked()) {
            resta = num1 - num2;
            result = " La resta es: " + resta;
        }
        resultado.setText(result);
    }

    private boolean validacion() {
        if (number1.length() == 0 && number2.length() == 0) {
            number1.setError("Required");
            number2.setError("Required");
            Toast.makeText(this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (number1.length() == 0) {
            number1.setError("Required");
            Toast.makeText(this, "Ingrese informacion para el primer campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para el primer campo");
            return false;
        }
        if (number2.length() == 0) {
            number2.setError("Required");
            Toast.makeText(this, "Ingrese informacion para el segundo campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para el segundo campo");
            return false;
        }
        if (!cbc1.isChecked() && !cbc2.isChecked()) {
            cbc1.setError("");
            cbc2.setError("");
            Toast.makeText(this, "Seleccione una opcion", Toast.LENGTH_LONG).show();
            Log.d("Validate", "Required // Seleccione una opcion");
            return false;

        }
        if (cbc1.isChecked() && cbc2.isChecked()) {
            cbc1.setError("");
            cbc2.setError("");
            Toast.makeText(this, "Permitido seleccionar solo uno", Toast.LENGTH_LONG).show();
            Log.d("Validate", "Required // Permitido seleccionar solo uno");
            return false;
        }
        else {
            Toast.makeText(this, "Validando la informacion", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Validando // Validando los campos con la informacion suministrada ");
        }
        operacion();
        return false;
    }
    private void reset() {
        number1.setText(null);
        number2.setText(null);
        number1.setError(null);
        number2.setError(null);
        cbc1.setError(null);
        cbc2.setError(null);
        resultado.setText(null);
        if (cbc1.isChecked()) {
            cbc1.toggle();
        }
        if (cbc2.isChecked()) {
            cbc2.toggle();
        }
    }

    private void reset2() {
        if (cbc1.isChecked() && !cbc2.isChecked()) {
            cbc1.setError(null);
            cbc2.setError(null);
        }
        if (cbc2.isChecked() && !cbc1.isChecked()) {
            cbc1.setError(null);
            cbc2.setError(null);
        }
    }
}