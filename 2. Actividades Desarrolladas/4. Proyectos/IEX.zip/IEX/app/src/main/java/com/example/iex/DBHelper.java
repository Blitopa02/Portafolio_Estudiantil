package com.example.iex;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "iexdb";
    public static final int DATABASE_VERSION = 1;
    public static final String TABLE_USER = "user";
    public static final String USER_ID = "id_user";
    public static final String USER_USERNAME = "username";
    public static final String USER_PASSWORD = "password";
    public static final String USER_ID_ROL = "id_rol";
    public static final String USER_HORARIO = "horario"; // Nuevo campo

    public DBHelper(Context context) {
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
        // Verificar si los usuarios ya existen antes de agregarlos
        if (verificarUsuarioExistente("user")) {
            agregarUsuario("user", "1", "2", "6-2:30"); // Agrega el rol 2 y el horario
        }
        if (verificarUsuarioExistente("user2")) {
            agregarUsuario("user2", "1", "2", "7:00-3:30"); // Agrega el rol 1 y el horario
        }
    }
    // Método para verificar si un usuario ya existe en la base de datos
    boolean verificarUsuarioExistente(String nombreUsuario) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, null, USER_USERNAME + "=?",
                new String[]{nombreUsuario}, null, null, null);

        boolean existeUsuario = cursor.getCount() > 0;

        cursor.close();
        this.close();

        return !existeUsuario;
    }

    public void abrir(){
        this.getWritableDatabase();
    }
    public void cerrar(){
        this.close();
    }

    public static String encriptarContrasena(String contrasena) {
        return contrasena;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE " + TABLE_USER +
                "(" + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_USERNAME + " TEXT, " +
                USER_PASSWORD + " TEXT, " +
                USER_ID_ROL + " INTEGER DEFAULT 1, " +
                USER_HORARIO + " TEXT)"; // Agrega el campo horario

        db.execSQL(createUserTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        onCreate(db);
    }

    public void agregarUsuario(String nombreUsuario, String contrasena, String idRol, String horario) {
        ContentValues values = new ContentValues();
        values.put(USER_USERNAME, nombreUsuario);
        values.put(USER_PASSWORD, contrasena);
        values.put(USER_ID_ROL, idRol);
        values.put(USER_HORARIO, horario); // Agrega el horario

        this.getWritableDatabase().insert(TABLE_USER,null,values);
        this.close();
    }

    public Cursor obtenerUsuarios() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USER, null, null, null, null, null, null);
    }

    @SuppressLint("Range")
    public int obtenerIdUsuario(String nombreUsuario) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{USER_ID}, USER_USERNAME + "=?",
                new String[]{nombreUsuario}, null, null, null);

        int id = -1;

        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndex(USER_ID));
        }

        cursor.close();
        this.close();

        return id;
    }

    @SuppressLint("Range")
    public int obtenerRolPorDefecto(int idUsuario) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{USER_ID_ROL}, USER_ID + "=?",
                new String[]{String.valueOf(idUsuario)}, null, null, null);

        int rol = 1; // Por defecto, rol es 1 (Agente)

        if (cursor.moveToFirst()) {
            rol = cursor.getInt(cursor.getColumnIndex(USER_ID_ROL));
        }

        cursor.close();
        this.close();

        return rol;
    }

    @SuppressLint("Range")
    public String obtenerContrasenaEncriptada(String nombreUsuario) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{USER_PASSWORD}, USER_USERNAME + "=?",
                new String[]{nombreUsuario}, null, null, null);

        String contrasenaEncriptada = null;

        if (cursor.moveToFirst()) {
            contrasenaEncriptada = cursor.getString(cursor.getColumnIndex(USER_PASSWORD));
        }

        cursor.close();
        this.close();

        return contrasenaEncriptada;
    }
}
