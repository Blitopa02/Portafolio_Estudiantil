package com.example.act2_testap;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.snackbar.Snackbar;
import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private Button bu;
    private TextView textViewDate, textViewTime;
    private String currentDate, currentTime;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendar = (Calendar) calendar.getInstance();
        currentDate = (String) DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = (String) DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());

        textViewDate = (TextView) findViewById(R.id.textView_date);
        textViewDate.setText(currentDate);
        textViewTime = (TextView) findViewById(R.id.textView_time);
        textViewTime.setText(currentTime);
        bu = (Button) findViewById(R.id.bu);

        bu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                cerrar();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(MainActivity.this, "Iniciando", Toast.LENGTH_SHORT).show(); // La actividad está a punto de hacerse visible.
        Log.d("Date and Time", "La fecha y hora actual es: " + currentDate + " " + currentTime);
        Log.d("Start", "Iniciando // La actividad está a punto de hacerse visible");
        Log.d("Materia", "Materia: Programacion VI - Asignacion N2");
        Log.d("Nombre", "Estudiante: Pablo Testa");
        Log.d("Cedula", "Cedula: 8-843-1065");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "en Pausa", Toast.LENGTH_SHORT).show(); // Enfocarse en otra actividad (esta actividad está a punto de ser"detenida").
        Log.d("Pause", "es Pausa // Enfocarse en otra actividad (esta actividad está a punto de ser\"detenida\").");
    }

    protected void cerrar() {
        Toast.makeText(MainActivity.this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        finish();
        System.exit(0);
    }
}