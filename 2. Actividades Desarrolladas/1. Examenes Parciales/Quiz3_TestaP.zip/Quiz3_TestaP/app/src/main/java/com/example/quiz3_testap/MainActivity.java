package com.example.quiz3_testap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView date, time, resultado;
    private EditText ed1, ed2, ed3;
    private Calendar calendar;
    private String currentDate, currentTime, val1, val2, val3, result;
    private Double a, b, c, x;
    private Button operation, reset, close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);
        operation = findViewById(R.id.operation);
        reset = findViewById(R.id.reset);
        close = findViewById(R.id.close);
        resultado = findViewById(R.id.resultado);
        operation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                validation();
                closeKeyboard();
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                cerrar();
            }
        });
    }
    private boolean validation() {
        if (ed1.length() == 0 && ed2.length() == 0 && ed3.length() == 0) {
            ed1.setError("Required");
            ed2.setError("Required");
            ed3.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (ed1.length() == 0 && ed2.length() == 0) {
            ed1.setError("Required");
            ed2.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (ed1.length() == 0 && ed3.length() == 0) {
            ed1.setError("Required");
            ed3.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (ed2.length() == 0 && ed3.length() == 0) {
            ed2.setError("Required");
            ed3.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (ed1.length() == 0) {
            ed1.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en el primer campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion en el primer campo");
            return false;
        }
        if (ed2.length() == 0) {
            ed2.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en el segundo campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion en el segundo campo");
            return false;
        }
        if (ed3.length() == 0) {
            ed3.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en el tercer campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion en el tercer campo ");
            return false;
        }
        else {
            Toast.makeText(MainActivity.this, "Validando la informacion", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Validando // Validando los campos con la informacion suministrada ");
        }
        operation();
        return false;
    }
    private boolean operation() {
        val1 = ed1.getText().toString();
        val2 = ed2.getText().toString();
        val3 = ed3.getText().toString();
        a = Double.parseDouble(val1);
        b = Double.parseDouble(val2);
        c = Double.parseDouble(val3);

        x = (a*b)*c;
        result = "El precio final es: \n$ " + x;
        resultado.setText(result);

        return false;
    }
    private void cerrar() {
        Toast.makeText(MainActivity.this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        MainActivity.this.finish();
        System.exit(0);
    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(MainActivity.this, "Iniciando", Toast.LENGTH_SHORT).show(); // La actividad está a punto de hacerse visible.
        Log.d("Date and Time", "La fecha y hora actual es: " + currentDate + " " + currentTime);
        Log.d("Start", "Iniciando // La actividad está a punto de recurse visible");
        Log.d("Materia", "Materia: Programacion VI - Quiz N3");
        Log.d("Nombre", "Estudiante: Pablo Testa");
        Log.d("Cedula", "Cedula: 8-843-1065");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });
    }
    private void reset() {
        ed1.setText(null);
        ed2.setText(null);
        ed3.setText(null);
        ed1.setError(null);
        ed2.setError(null);
        ed3.setError(null);
        resultado.setText(null);
    }
    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "en Pausa", Toast.LENGTH_SHORT).show(); // Enfocarse en otra actividad (esta actividad está a punto de ser"detenida").
        Log.d("Pause", "es Pausa // Enfocarse en otra actividad (esta actividad está a punto de ser\"detenida\").");
    }
}