package com.example.iex;

import android.os.Bundle;
//import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CrearUsuarioActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextContrasena;
    private Spinner spinnerHorario;
    Button buttonCrearUsuario;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crearusuario);

        dbHelper = new DBHelper(this);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextContrasena = findViewById(R.id.editTextContrasena);
        spinnerHorario = findViewById(R.id.spinnerHorario); // Cambiado a Spinner
        buttonCrearUsuario = findViewById(R.id.buttonCrearUsuario);

        buttonCrearUsuario.setOnClickListener(v -> {
            dbHelper.abrir();
            crearUsuario();
        });
    }

    private void crearUsuario() {
        String nombreUsuario = editTextNombre.getText().toString().trim();
        String contrasena = editTextContrasena.getText().toString().trim();
        String horario = spinnerHorario.getSelectedItem().toString(); // Obtén el horario del Spinner

        if (nombreUsuario.isEmpty() || contrasena.isEmpty() || horario.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.verificarUsuarioExistente(nombreUsuario)) {
            dbHelper.agregarUsuario(nombreUsuario, contrasena, "1", horario);
            Toast.makeText(this, "Usuario creado exitosamente.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "El usuario ya existe.", Toast.LENGTH_SHORT).show();
        }
    }
}
