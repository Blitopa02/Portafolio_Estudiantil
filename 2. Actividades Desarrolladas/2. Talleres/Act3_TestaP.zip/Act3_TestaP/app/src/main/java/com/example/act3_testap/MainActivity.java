package com.example.act3_testap;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView textView_date, textView_time, resultado;
    private EditText number1, number2;
    private RadioButton sumar,restar;
    private String valor1, valor2, result, currentDate, currentTime;
    private Integer num1, num2, suma, resta;
    private Calendar calendar;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());

        textView_date = findViewById(R.id.textView_date);
        textView_time = findViewById(R.id.textView_time);
        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        sumar = findViewById(R.id.r1);
        restar = findViewById(R.id.r2);
        resultado = findViewById(R.id.resultado);

        textView_date.setText(currentDate);
        textView_time.setText(currentTime);
    }
    public void operacion(View View){
         valor1=number1.getText().toString();
         valor2=number2.getText().toString();
         num1 = Integer.parseInt(valor1);
         num2 = Integer.parseInt(valor2);
        if (sumar.isChecked()){
             suma = num1 + num2;
             result=String.valueOf(suma);
            resultado.setText(result);
        }
        else
        if (restar.isChecked()){
            resta = num1 - num2;
            result=String.valueOf(resta);
            resultado.setText(result);
        }
    }

}