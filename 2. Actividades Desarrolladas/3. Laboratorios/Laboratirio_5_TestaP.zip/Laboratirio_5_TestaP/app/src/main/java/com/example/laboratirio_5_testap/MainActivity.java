package com.example.laboratirio_5_testap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView date, time;
    private Calendar calendar;
    private String currentDate, currentTime;
    private Button verify, close;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch s1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        verify = findViewById(R.id.verify);
        close = findViewById(R.id.close);
        s1 = findViewById(R.id.s1);
        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dark();
            }
        });
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                validation();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                cerrar();
            }
        });
    }
    private void validation() {
        Intent val = new Intent(this,Menu.class);
        startActivity(val);
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Date and Time", "La fecha y hora actual es: " + currentDate + " " + currentTime);
        Log.d("Start", "Iniciando // La actividad está a punto de recurse visible");
        Log.d("Materia", "Materia: Programacion VI - Quiz N3");
        Log.d("Nombre", "Estudiante: Pablo Testa");
        Log.d("Cedula", "Cedula: 8-843-1065");
        }
    private void dark(){
        if (s1.isChecked()){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(MainActivity.this, "Dark Mode Activado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "ON // El tema dark ha sido activado");
        }
        else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(MainActivity.this, "Dark Mode Desactivado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "OFF // El tema dark ha sido desactivado");
        }
    }
    private void cerrar() {
        Toast.makeText(this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        this.finish();
        System.exit(0);
    }
    }