package com.example.iex;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.util.Calendar;

public class ScheduleActivity1 extends AppCompatActivity {
    private TextView date, time, e1,e2,e3,e4,e5,e6,e7,e8,e9;
    private Calendar calendar;
    private String currentDate, currentTime, a1,a2,a3,a4,a5,a6,a7,a8,a9;

    private Button b1, b2, b3, b4, b5, b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule1_2);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);
        e5 = findViewById(R.id.e5);
        e6 = findViewById(R.id.e6);
        e7 = findViewById(R.id.e7);
        e8 = findViewById(R.id.e8);
        e9 = findViewById(R.id.e9);
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        Intent save = getIntent();

        a1 = save.getStringExtra("e1");
        a2 = save.getStringExtra("e2");
        a3 = save.getStringExtra("e3");
        a4 = save.getStringExtra("e4");
        a5 = save.getStringExtra("e5");
        a6 = save.getStringExtra("e6");
        a7 = save.getStringExtra("e7");
        a8 = save.getStringExtra("e8");
        a9 = save.getStringExtra("e9");

        e1.setText(a1);
        e2.setText(a2);
        e3.setText(a3);
        e4.setText(a4);
        e5.setText(a5);
        e6.setText(a6);
        e7.setText(a7);
        e8.setText(a8);
        e9.setText(a9);

    }

    private void back() {
        Intent back = new Intent(this, LogInActivity.class);
        startActivity(back);
    }
}
