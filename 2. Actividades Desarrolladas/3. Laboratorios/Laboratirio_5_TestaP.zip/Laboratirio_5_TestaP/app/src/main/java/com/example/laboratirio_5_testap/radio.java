package com.example.laboratirio_5_testap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class radio extends AppCompatActivity {
    private TextView date, time, resultado;
    private Calendar calendar;
    private String valor1, valor2, result, currentDate, currentTime;
    private Button b1, b2, b3, b4, b5, b6;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch s1;
    private EditText number1, number2;
    private RadioButton sumar,restar;
    private Integer num1, num2, suma, resta;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        s1 = findViewById(R.id.s1);
        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dark();
            }
        });
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        sumar = findViewById(R.id.r1);
        restar = findViewById(R.id.r2);
        resultado = findViewById(R.id.resultado);
    }
    private void dark() {
        if (s1.isChecked()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(this, "Dark Mode Activado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "ON // El tema dark ha sido activado");
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Dark Mode Desactivado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "OFF // El tema dark ha sido desactivado");
        }
    }
    private void back() {
        Intent back = new Intent(this,Menu.class);
        startActivity(back);
    }
    public void operacion(View View){
        valor1=number1.getText().toString();
        valor2=number2.getText().toString();
        num1 = Integer.parseInt(valor1);
        num2 = Integer.parseInt(valor2);
        if (sumar.isChecked()){
            suma = num1 + num2;
            result=String.valueOf(suma);
            resultado.setText(result);
        }
        else
        if (restar.isChecked()){
            resta = num1 - num2;
            result=String.valueOf(resta);
            resultado.setText(result);
        }
    }

}