package com.example.iex;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import java.text.DateFormat;
import java.util.Calendar;

public class LogInActivity extends AppCompatActivity {
    private TextView date, time, resultado;
    private EditText editTextContrasena, editTextNombre;
    private Calendar calendar;
    private String currentDate, currentTime;
    private Button buttonIniciarSesion, close;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    Switch s1;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextContrasena = findViewById(R.id.editTextContrasena);

        dbHelper = new DBHelper(this);

        buttonIniciarSesion = findViewById(R.id.buttonIniciarSesion);
        buttonIniciarSesion.setOnClickListener(view -> {
            iniciarSesion();
            closeKeyboard();
        });
        s1 = findViewById(R.id.s1);
        s1.setOnClickListener(v -> dark());
        close = findViewById(R.id.close);
        close.setOnClickListener(View -> close());
    }

    private void iniciarSesion() {
        // Obtener datos de inicio de sesión
        String nombreUsuario = editTextNombre.getText().toString().trim();
        String contrasena = editTextContrasena.getText().toString().trim();

        // Verificar que se ingresaron datos
        if (nombreUsuario.isEmpty() || contrasena.isEmpty()) {
            Toast.makeText(this, "Por favor, ingresa nombre de usuario y contraseña.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar que el usuario esté registrado
        if (verificarUsuarioRegistrado(nombreUsuario, contrasena)) {
            // Obtener el ID del usuario
            int idUsuario = dbHelper.obtenerIdUsuario(nombreUsuario);

            // Verificar el rol por defecto del usuario
            int rolPorDefecto = dbHelper.obtenerRolPorDefecto(idUsuario);

            // Redirigir según el rol
            if (rolPorDefecto == 2) {
                abrirScheduleActivity();
            } else {
                abrirWorkforceActivity();
            }
        } else {
            // Mostrar mensaje de error si el usuario no está registrado
            Toast.makeText(this, "Usuario no registrado o contraseña incorrecta.", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para verificar si el usuario está registrado
    private boolean verificarUsuarioRegistrado(String nombreUsuario, String contrasena) {

        try (SQLiteDatabase db = dbHelper.getReadableDatabase(); Cursor cursor = db.query("user", null,
                "username=? AND password=?",
                new String[]{nombreUsuario, DBHelper.encriptarContrasena(contrasena)},
                null, null, null)) {

            // Consultar la tabla User para verificar el usuario y contraseña

            return cursor.moveToFirst();
        }
    }

    private void abrirScheduleActivity() {
        Intent intent = new Intent(this, ScheduleActivity1.class);
        startActivity(intent);
    }

    private void abrirWorkforceActivity() {
        Intent intent = new Intent(this, WorkforceActivity.class);
        startActivity(intent);
        finish();
    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    private void close() {
        Toast.makeText(this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        this.finish();
        System.exit(0);
    }
    private void dark() {
        if (s1.isChecked()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(this, "Dark Mode Activado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "ON // El tema dark ha sido activado");
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Dark Mode Desactivado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "OFF // El tema dark ha sido desactivado");
        }
    }
}
