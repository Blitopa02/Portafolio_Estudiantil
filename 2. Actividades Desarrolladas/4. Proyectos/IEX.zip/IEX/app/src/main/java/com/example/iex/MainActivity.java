package com.example.iex;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView date, time;
    private EditText e1,e2,e3,e4,e5,e6,e7,e8,e9;
    private Calendar calendar;
    private String currentDate, currentTime, a1,a2,a3,a4,a5,a6,a7,a8,a9;

    private Button b1, b2, b3, b4, b5, b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule1_1);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);
        e5 = findViewById(R.id.e5);
        e6 = findViewById(R.id.e6);
        e7 = findViewById(R.id.e7);
        e8 = findViewById(R.id.e8);
        e9 = findViewById(R.id.e9);
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
    }

    public void save() {
        a1 = e1.getText().toString();
        a2 = e2.getText().toString();
        a3 = e3.getText().toString();
        a4 = e4.getText().toString();
        a5 = e5.getText().toString();
        a6 = e6.getText().toString();
        a7 = e7.getText().toString();
        a8 = e8.getText().toString();
        a9 = e9.getText().toString();
        Intent save = new Intent(this, ScheduleActivity1.class);
        save.putExtra("e1",a1);
        save.putExtra("e2",a2);
        save.putExtra("e3",a3);
        save.putExtra("e4",a4);
        save.putExtra("e5",a5);
        save.putExtra("e6",a6);
        save.putExtra("e7",a7);
        save.putExtra("e8",a8);
        save.putExtra("e9",a9);
        startActivity(save);
    }

}
