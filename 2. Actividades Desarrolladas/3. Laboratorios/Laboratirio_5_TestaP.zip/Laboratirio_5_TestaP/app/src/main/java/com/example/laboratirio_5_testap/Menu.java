package com.example.laboratirio_5_testap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class Menu extends AppCompatActivity {
    private TextView date, time;
    private Calendar calendar;
    private String currentDate, currentTime;

    private Button b1, b2, b3, b4, b5, b6;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch s1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        s1 = findViewById(R.id.s1);
        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dark();
            }
        });
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });

        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                radio();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                check();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                spinner();
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                image();
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                sw();
            }
        });

    }
    private void back() {
        Intent back = new Intent(this,MainActivity.class);
        startActivity(back);
    }
    private void radio() {
        Intent radio = new Intent(this,radio.class);
        startActivity(radio);
    }
    private void check() {
        Intent check = new Intent(this,check.class);
        startActivity(check);
    }
    private void spinner() {
        Intent spinner = new Intent(this,spinner.class);
        startActivity(spinner);
    }
    private void image() {
        Intent image = new Intent(this,image.class);
        startActivity(image);
    }
    private void sw() {
        Intent sw = new Intent(this,sw.class);
        startActivity(sw);
    }
    private void dark() {
        if (s1.isChecked()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(this, "Dark Mode Activado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "ON // El tema dark ha sido activado");
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Dark Mode Desactivado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "OFF // El tema dark ha sido desactivado");
        }
    }
}