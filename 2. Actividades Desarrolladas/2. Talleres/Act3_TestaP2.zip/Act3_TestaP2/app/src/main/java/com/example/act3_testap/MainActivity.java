package com.example.act3_testap;


import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView resultado, textView_date, textView_time;
    private EditText number1, number2;
    private CheckBox cbc1, cbc2;
    private Calendar calendar;
    private String currentDate, currentTime, valor1, valor2, result;
    private Button b1, b2, b3;
    private Integer num1, num2, suma, resta;
    boolean isAllFieldsChecked = false;

    @SuppressLint("MissingInflatedId")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView_date = findViewById(R.id.textView_date);
        textView_time = findViewById(R.id.textView_time);
        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        cbc1 = findViewById(R.id.cbc1);
        cbc2 = findViewById(R.id.cbc2);
        resultado = findViewById(R.id.resultado);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        textView_date.setText(currentDate);
        textView_time.setText(currentTime);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isAllFieldsChecked = validacion();
                closeKeyboard();
                reset2();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                cerrar();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(MainActivity.this, "Iniciando", Toast.LENGTH_SHORT).show(); // La actividad está a punto de hacerse visible.
        Log.d("Date and Time", "La fecha y hora actual es: " + currentDate + " " + currentTime);
        Log.d("Start", "Iniciando // La actividad está a punto de hacerse visible");
        Log.d("Materia", "Materia: Programacion VI - Asignacion N2");
        Log.d("Nombre", "Estudiante: Pablo Testa");
        Log.d("Cedula", "Cedula: 8-843-1065");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                reset();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "en Pausa", Toast.LENGTH_SHORT).show(); // Enfocarse en otra actividad (esta actividad está a punto de ser"detenida").
        Log.d("Pause", "es Pausa // Enfocarse en otra actividad (esta actividad está a punto de ser\"detenida\").");
    }

    private void cerrar() {
        Toast.makeText(MainActivity.this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        MainActivity.this.finish();
        System.exit(0);
    }

    private void reset() {
        number1.setText(null);
        number2.setText(null);
        number1.setError(null);
        number2.setError(null);
        cbc1.setError(null);
        cbc2.setError(null);
        resultado.setText(null);
        if (cbc1.isChecked()) {
            cbc1.toggle();
        }
        if (cbc2.isChecked()) {
            cbc2.toggle();
        }
    }

    private void reset2() {
        if (cbc1.isChecked() && !cbc2.isChecked()) {
            cbc1.setError(null);
            cbc2.setError(null);
        }
        if (cbc2.isChecked() && !cbc1.isChecked()) {
            cbc1.setError(null);
            cbc2.setError(null);
        }
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void operacion() {
        valor1 = number1.getText().toString();
        valor2 = number2.getText().toString();
        num1 = Integer.parseInt(valor1);
        num2 = Integer.parseInt(valor2);
        result = "";
        if (cbc1.isChecked()) {
            suma = num1 + num2;
            result = "La suma es: " + suma;
        }
        if (cbc2.isChecked()) {
            resta = num1 - num2;
            result = " La resta es: " + resta;
        }
        resultado.setText(result);
    }

    private boolean validacion() {
        if (number1.length() == 0 && number2.length() == 0) {
            number1.setError("Required");
            number2.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (number1.length() == 0) {
            number1.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion para el primer campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para el primer campo");
            return false;
        }
        if (number2.length() == 0) {
            number2.setError("Required");
            Toast.makeText(MainActivity.this, "Ingrese informacion para el segundo campo", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para el segundo campo");
            return false;
        }
        if (!cbc1.isChecked() && !cbc2.isChecked()) {
            cbc1.setError("");
            cbc2.setError("");
            Toast.makeText(MainActivity.this, "Seleccione una opcion", Toast.LENGTH_LONG).show();
            Log.d("Validate", "Required // Seleccione una opcion");
            return false;

        }
        if (cbc1.isChecked() && cbc2.isChecked()) {
            cbc1.setError("");
            cbc2.setError("");
            Toast.makeText(MainActivity.this, "Permitido seleccionar solo uno", Toast.LENGTH_LONG).show();
            Log.d("Validate", "Required // Permitido seleccionar solo uno");
            return false;
        }
        else {
            Toast.makeText(MainActivity.this, "Validando la informacion", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Validando // Validando los campos con la informacion suministrada ");
        }
        operacion();
        return false;
    }
}
        /**
         cb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
         @Override
         public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               if (isChecked){
                 b.setVisibility(View.VISIBLE);
              }else {
        b.setVisibility(View.INVISIBLE);
             }
           }
        });
        cb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
          @Override
           public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               if (isChecked){
                    b.setVisibility(View.VISIBLE);
               }else {
                   b.setVisibility(View.INVISIBLE);
            }
            }
        });*/