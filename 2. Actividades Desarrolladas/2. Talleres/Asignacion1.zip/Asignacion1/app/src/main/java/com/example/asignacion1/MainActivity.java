package com.example.asignacion1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import java.security.PrivateKey;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private TextView textViewDate;
    private TextView textViewTime;
    private String currentDate;
    private String currentTime;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());

        textViewDate = findViewById(R.id.textView_date);
        textViewTime = findViewById(R.id.textView_time);

        textViewDate.setText(currentDate);
        textViewTime.setText(currentTime);

        Log.d("Date and Time", "La fecha y hora actual es: "+currentDate+" "+currentTime);
        Log.d("Materia","Materia: Programacion VI - Asignacion N1");
        Log.d("Nombre","Estudiante: Pablo Testa");
        Log.d("Hola", "Hola Mundo ");
    }
}