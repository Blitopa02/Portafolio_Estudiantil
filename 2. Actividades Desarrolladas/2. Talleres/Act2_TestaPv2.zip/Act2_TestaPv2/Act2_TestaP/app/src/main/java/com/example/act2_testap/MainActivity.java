package com.example.act2_testap;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.snackbar.Snackbar;
import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private Button bu;
    private TextView textViewDate;
    private TextView textViewTime;
    private String currentDate;
    private String currentTime;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());

        textViewDate = findViewById(R.id.textView_date);
        textViewTime = findViewById(R.id.textView_time);

        textViewDate.setText(currentDate);
        textViewTime.setText(currentTime);

        Log.d("Date and Time", "La fecha y hora actual es: "+currentDate+" "+currentTime);
        Log.d("Materia","Materia: Programacion VI - Asignacion N2");
        Log.d("Nombre","Estudiante: Pablo Testa");
        Log.d("Cedula","Cedula: 8-843-1065");

        bu = (Button) findViewById(R.id.bu);

        bu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                Toast.makeText(MainActivity.this, "Cerrando", Toast.LENGTH_SHORT).show();
                finish();
                System.exit(0);
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(MainActivity.this, "Iniciando", Toast.LENGTH_SHORT).show(); // La actividad está a punto de hacerse visible.
    }
    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "en Pausa", Toast.LENGTH_SHORT).show(); // Enfocarse en otra actividad (esta actividad está a punto de ser"detenida").
    }
}
