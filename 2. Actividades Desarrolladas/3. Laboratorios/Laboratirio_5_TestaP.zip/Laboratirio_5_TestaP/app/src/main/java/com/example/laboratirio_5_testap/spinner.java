package com.example.laboratirio_5_testap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class spinner extends AppCompatActivity {
    private TextView date, time;
    private Calendar calendar;
    private String currentDate, currentTime;
    private EditText ed1, ed2;
    private Button verify, reset, close, b1;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch s1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);
        date = findViewById(R.id.date);
        time = findViewById(R.id.time);
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar.getTime());
        currentTime = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
        date.setText(currentDate);
        time.setText(currentTime);
        s1 = findViewById(R.id.s1);
        s1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dark();
            }
        });
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        verify = findViewById(R.id.verify);
        reset = findViewById(R.id.reset);
        close = findViewById(R.id.close);
        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                validation();
                closeKeyboard();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                cerrar();
            }
        });

    }
    private boolean validation() {
        if (ed1.length() == 0 && ed2.length() == 0) {
            ed1.setError("Required");
            ed2.setError("Required");
            Toast.makeText(this, "Ingrese informacion en los campos requeridos", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion para todos los campos requeridos");
            return false;
        }
        if (ed1.length() == 0) {
            ed1.setError("Required");
            Toast.makeText(this, "El usuario no puede quedar vacio", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion en el primer campo");
            return false;
        }
        if (ed2.length() == 0) {
            ed2.setError("Required");
            Toast.makeText(this, "La clave no puede quedar vacia", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Required // Ingrese informacion en el segundo campo");
            return false;
        }
        else {
            Toast.makeText(this, "Validando la informacion", Toast.LENGTH_LONG).show();
            Log.e("Validate", "Validando // Validando los campos con la informacion suministrada ");
        }
        return false;
    }
    private void cerrar() {
        Toast.makeText(this, "Cerrando", Toast.LENGTH_SHORT).show(); // La actividad ya no es visible (ahora esta "detenida").
        Log.d("Cerrar", "Cerrando // La actividad ya no es visible (ahora esta \"detenida\").");
        this.finish();
        System.exit(0);
    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Date and Time", "La fecha y hora actual es: " + currentDate + " " + currentTime);
        Log.d("Start", "Iniciando // La actividad está a punto de recurse visible");
        Log.d("Materia", "Materia: Programacion VI - Quiz N3");
        Log.d("Nombre", "Estudiante: Pablo Testa");
        Log.d("Cedula", "Cedula: 8-843-1065");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });
    }
    private void reset() {
        ed1.setText(null);
        ed2.setText(null);
        ed1.setError(null);
        ed2.setError(null);
    }
    private void dark() {
        if (s1.isChecked()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(this, "Dark Mode Activado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "ON // El tema dark ha sido activado");
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Dark Mode Desactivado", Toast.LENGTH_LONG).show();
            Log.e("Dark_Mode", "OFF // El tema dark ha sido desactivado");
        }
    }
    private void back() {
        Intent back = new Intent(this,Menu.class);
        startActivity(back);
    }
}